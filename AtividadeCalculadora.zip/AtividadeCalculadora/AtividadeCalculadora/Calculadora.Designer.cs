﻿
namespace AtividadeCalculadora
{
    partial class Calculadora
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_ON = new System.Windows.Forms.Button();
            this.btn_0 = new System.Windows.Forms.Button();
            this.btn_1 = new System.Windows.Forms.Button();
            this.btn_4 = new System.Windows.Forms.Button();
            this.btn_7 = new System.Windows.Forms.Button();
            this.btn_C = new System.Windows.Forms.Button();
            this.btn_5 = new System.Windows.Forms.Button();
            this.btn_2 = new System.Windows.Forms.Button();
            this.btn_00 = new System.Windows.Forms.Button();
            this.btn_9 = new System.Windows.Forms.Button();
            this.btn_6 = new System.Windows.Forms.Button();
            this.btn_3 = new System.Windows.Forms.Button();
            this.btn_ponto = new System.Windows.Forms.Button();
            this.btn_8 = new System.Windows.Forms.Button();
            this.btn_mul = new System.Windows.Forms.Button();
            this.btn_Ad = new System.Windows.Forms.Button();
            this.btn_div = new System.Windows.Forms.Button();
            this.btn_sub = new System.Windows.Forms.Button();
            this.btn_igual = new System.Windows.Forms.Button();
            this.rTB_result = new System.Windows.Forms.RichTextBox();
            this.Lb_casio = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Lb_embranco = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_ON
            // 
            this.btn_ON.Location = new System.Drawing.Point(236, 128);
            this.btn_ON.Name = "btn_ON";
            this.btn_ON.Size = new System.Drawing.Size(106, 36);
            this.btn_ON.TabIndex = 0;
            this.btn_ON.Text = "ON";
            this.btn_ON.UseVisualStyleBackColor = true;
            this.btn_ON.Click += new System.EventHandler(this.btn_ON_Click);
            // 
            // btn_0
            // 
            this.btn_0.Location = new System.Drawing.Point(68, 254);
            this.btn_0.Name = "btn_0";
            this.btn_0.Size = new System.Drawing.Size(50, 36);
            this.btn_0.TabIndex = 1;
            this.btn_0.Text = "0";
            this.btn_0.UseVisualStyleBackColor = true;
            this.btn_0.Click += new System.EventHandler(this.btn_0_Click);
            // 
            // btn_1
            // 
            this.btn_1.Location = new System.Drawing.Point(68, 212);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(50, 36);
            this.btn_1.TabIndex = 2;
            this.btn_1.Text = "1";
            this.btn_1.UseVisualStyleBackColor = true;
            this.btn_1.Click += new System.EventHandler(this.btn_1_Click);
            // 
            // btn_4
            // 
            this.btn_4.Location = new System.Drawing.Point(68, 170);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(50, 36);
            this.btn_4.TabIndex = 3;
            this.btn_4.Text = "4";
            this.btn_4.UseVisualStyleBackColor = true;
            this.btn_4.Click += new System.EventHandler(this.btn_4_Click);
            // 
            // btn_7
            // 
            this.btn_7.Location = new System.Drawing.Point(68, 128);
            this.btn_7.Name = "btn_7";
            this.btn_7.Size = new System.Drawing.Size(50, 36);
            this.btn_7.TabIndex = 4;
            this.btn_7.Text = "7";
            this.btn_7.UseVisualStyleBackColor = true;
            this.btn_7.Click += new System.EventHandler(this.btn_7_Click);
            // 
            // btn_C
            // 
            this.btn_C.Location = new System.Drawing.Point(12, 128);
            this.btn_C.Name = "btn_C";
            this.btn_C.Size = new System.Drawing.Size(50, 162);
            this.btn_C.TabIndex = 5;
            this.btn_C.Text = "C";
            this.btn_C.UseVisualStyleBackColor = true;
            this.btn_C.Click += new System.EventHandler(this.btn_C_Click);
            // 
            // btn_5
            // 
            this.btn_5.Location = new System.Drawing.Point(124, 170);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(50, 36);
            this.btn_5.TabIndex = 15;
            this.btn_5.Text = "5";
            this.btn_5.UseVisualStyleBackColor = true;
            this.btn_5.Click += new System.EventHandler(this.btn_5_Click);
            // 
            // btn_2
            // 
            this.btn_2.Location = new System.Drawing.Point(124, 212);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(50, 36);
            this.btn_2.TabIndex = 14;
            this.btn_2.Text = "2";
            this.btn_2.UseVisualStyleBackColor = true;
            this.btn_2.Click += new System.EventHandler(this.btn_2_Click);
            // 
            // btn_00
            // 
            this.btn_00.Location = new System.Drawing.Point(124, 254);
            this.btn_00.Name = "btn_00";
            this.btn_00.Size = new System.Drawing.Size(50, 36);
            this.btn_00.TabIndex = 13;
            this.btn_00.Text = "00";
            this.btn_00.UseVisualStyleBackColor = true;
            this.btn_00.Click += new System.EventHandler(this.btn_00_Click);
            // 
            // btn_9
            // 
            this.btn_9.Location = new System.Drawing.Point(180, 128);
            this.btn_9.Name = "btn_9";
            this.btn_9.Size = new System.Drawing.Size(50, 36);
            this.btn_9.TabIndex = 12;
            this.btn_9.Text = "9";
            this.btn_9.UseVisualStyleBackColor = true;
            this.btn_9.Click += new System.EventHandler(this.btn_9_Click);
            // 
            // btn_6
            // 
            this.btn_6.Location = new System.Drawing.Point(180, 170);
            this.btn_6.Name = "btn_6";
            this.btn_6.Size = new System.Drawing.Size(50, 36);
            this.btn_6.TabIndex = 11;
            this.btn_6.Text = "6";
            this.btn_6.UseVisualStyleBackColor = true;
            this.btn_6.Click += new System.EventHandler(this.btn_6_Click);
            // 
            // btn_3
            // 
            this.btn_3.Location = new System.Drawing.Point(180, 212);
            this.btn_3.Name = "btn_3";
            this.btn_3.Size = new System.Drawing.Size(50, 36);
            this.btn_3.TabIndex = 10;
            this.btn_3.Text = "3";
            this.btn_3.UseVisualStyleBackColor = true;
            this.btn_3.Click += new System.EventHandler(this.btn_3_Click);
            // 
            // btn_ponto
            // 
            this.btn_ponto.Location = new System.Drawing.Point(180, 254);
            this.btn_ponto.Name = "btn_ponto";
            this.btn_ponto.Size = new System.Drawing.Size(50, 36);
            this.btn_ponto.TabIndex = 9;
            this.btn_ponto.Text = ".";
            this.btn_ponto.UseVisualStyleBackColor = true;
            this.btn_ponto.Click += new System.EventHandler(this.btn_ponto_Click);
            // 
            // btn_8
            // 
            this.btn_8.Location = new System.Drawing.Point(124, 128);
            this.btn_8.Name = "btn_8";
            this.btn_8.Size = new System.Drawing.Size(50, 36);
            this.btn_8.TabIndex = 8;
            this.btn_8.Text = "8";
            this.btn_8.UseVisualStyleBackColor = true;
            this.btn_8.Click += new System.EventHandler(this.btn_8_Click);
            // 
            // btn_mul
            // 
            this.btn_mul.Location = new System.Drawing.Point(236, 170);
            this.btn_mul.Name = "btn_mul";
            this.btn_mul.Size = new System.Drawing.Size(50, 36);
            this.btn_mul.TabIndex = 23;
            this.btn_mul.Text = "x";
            this.btn_mul.UseVisualStyleBackColor = true;
            this.btn_mul.Click += new System.EventHandler(this.btn_mul_Click);
            // 
            // btn_Ad
            // 
            this.btn_Ad.Location = new System.Drawing.Point(236, 212);
            this.btn_Ad.Name = "btn_Ad";
            this.btn_Ad.Size = new System.Drawing.Size(50, 78);
            this.btn_Ad.TabIndex = 21;
            this.btn_Ad.Text = "+";
            this.btn_Ad.UseVisualStyleBackColor = true;
            this.btn_Ad.Click += new System.EventHandler(this.btn_Ad_Click);
            // 
            // btn_div
            // 
            this.btn_div.Location = new System.Drawing.Point(292, 170);
            this.btn_div.Name = "btn_div";
            this.btn_div.Size = new System.Drawing.Size(50, 36);
            this.btn_div.TabIndex = 19;
            this.btn_div.Text = "÷";
            this.btn_div.UseVisualStyleBackColor = true;
            this.btn_div.Click += new System.EventHandler(this.btn_div_Click);
            // 
            // btn_sub
            // 
            this.btn_sub.Location = new System.Drawing.Point(292, 212);
            this.btn_sub.Name = "btn_sub";
            this.btn_sub.Size = new System.Drawing.Size(50, 36);
            this.btn_sub.TabIndex = 18;
            this.btn_sub.Text = "-";
            this.btn_sub.UseVisualStyleBackColor = true;
            this.btn_sub.Click += new System.EventHandler(this.btn_sub_Click);
            // 
            // btn_igual
            // 
            this.btn_igual.Location = new System.Drawing.Point(292, 254);
            this.btn_igual.Name = "btn_igual";
            this.btn_igual.Size = new System.Drawing.Size(50, 36);
            this.btn_igual.TabIndex = 17;
            this.btn_igual.Text = "=";
            this.btn_igual.UseVisualStyleBackColor = true;
            this.btn_igual.Click += new System.EventHandler(this.btn_igual_Click);
            // 
            // rTB_result
            // 
            this.rTB_result.Location = new System.Drawing.Point(12, 43);
            this.rTB_result.Name = "rTB_result";
            this.rTB_result.Size = new System.Drawing.Size(330, 64);
            this.rTB_result.TabIndex = 24;
            this.rTB_result.Text = "";
            // 
            // Lb_casio
            // 
            this.Lb_casio.AutoSize = true;
            this.Lb_casio.Font = new System.Drawing.Font("Gill Sans MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lb_casio.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.Lb_casio.Location = new System.Drawing.Point(12, 13);
            this.Lb_casio.Name = "Lb_casio";
            this.Lb_casio.Size = new System.Drawing.Size(76, 27);
            this.Lb_casio.TabIndex = 25;
            this.Lb_casio.Text = "CASIO";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Gill Sans MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.label1.Location = new System.Drawing.Point(310, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 27);
            this.label1.TabIndex = 26;
            this.label1.Text = "12";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Gill Sans MT", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.label2.Location = new System.Drawing.Point(260, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 16);
            this.label2.TabIndex = 27;
            this.label2.Text = "DX-120B";
            // 
            // Lb_embranco
            // 
            this.Lb_embranco.AutoSize = true;
            this.Lb_embranco.Font = new System.Drawing.Font("Gill Sans MT", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lb_embranco.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.Lb_embranco.Location = new System.Drawing.Point(31, 293);
            this.Lb_embranco.MinimumSize = new System.Drawing.Size(300, 0);
            this.Lb_embranco.Name = "Lb_embranco";
            this.Lb_embranco.Size = new System.Drawing.Size(300, 16);
            this.Lb_embranco.TabIndex = 28;
            // 
            // Calculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(359, 316);
            this.Controls.Add(this.Lb_embranco);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Lb_casio);
            this.Controls.Add(this.rTB_result);
            this.Controls.Add(this.btn_mul);
            this.Controls.Add(this.btn_Ad);
            this.Controls.Add(this.btn_div);
            this.Controls.Add(this.btn_sub);
            this.Controls.Add(this.btn_igual);
            this.Controls.Add(this.btn_5);
            this.Controls.Add(this.btn_2);
            this.Controls.Add(this.btn_00);
            this.Controls.Add(this.btn_9);
            this.Controls.Add(this.btn_6);
            this.Controls.Add(this.btn_3);
            this.Controls.Add(this.btn_ponto);
            this.Controls.Add(this.btn_8);
            this.Controls.Add(this.btn_C);
            this.Controls.Add(this.btn_7);
            this.Controls.Add(this.btn_4);
            this.Controls.Add(this.btn_1);
            this.Controls.Add(this.btn_0);
            this.Controls.Add(this.btn_ON);
            this.MaximizeBox = false;
            this.Name = "Calculadora";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CALCULADORA HARD";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_ON;
        private System.Windows.Forms.Button btn_0;
        private System.Windows.Forms.Button btn_1;
        private System.Windows.Forms.Button btn_4;
        private System.Windows.Forms.Button btn_7;
        private System.Windows.Forms.Button btn_C;
        private System.Windows.Forms.Button btn_5;
        private System.Windows.Forms.Button btn_2;
        private System.Windows.Forms.Button btn_00;
        private System.Windows.Forms.Button btn_9;
        private System.Windows.Forms.Button btn_6;
        private System.Windows.Forms.Button btn_3;
        private System.Windows.Forms.Button btn_ponto;
        private System.Windows.Forms.Button btn_8;
        private System.Windows.Forms.Button btn_mul;
        private System.Windows.Forms.Button btn_Ad;
        private System.Windows.Forms.Button btn_div;
        private System.Windows.Forms.Button btn_sub;
        private System.Windows.Forms.Button btn_igual;
        private System.Windows.Forms.RichTextBox rTB_result;
        private System.Windows.Forms.Label Lb_casio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Lb_embranco;
    }
}

